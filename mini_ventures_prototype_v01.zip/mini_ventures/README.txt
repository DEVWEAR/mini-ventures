MINI VENTURES — iPhone-friendly playable prototype v0.1
Open index.html in a browser, or host the folder on GitHub Pages for iPhone Safari.
Includes: animated customers, order serving, coins, kitchen upgrades, helpers, reputation, local save, Arabic/English.
This is a 2D prototype (not a completed 3D game). No real-money payments or ads are implemented.
